const url = `http://localhost:3000/books`;
const tbody = document.querySelector('tbody');
function showbooks(){
    fetch(url)
    .then(res => res.json())
    .then(data => {
        tbody.innerHTML = data.map((book,index) => {
            return `<tr>
                        <td>${index + 1}</td>
                        <td>${book.ten}</td>
                        <td>${book.nxb}</td>
                        <td>${book.namxb}</td>
                        <td>${book.gia}</td>
                        <td>
                            <button class="btn btn-primary btn-edit" data-id="${book.id}">Sửa</button>
                            <button class="btn btn-danger btn-delete" data-id="${book.id}">Xóa</button>
                        </td>
                    </tr>`
        }).join('');
        document.querySelectorAll('.btn-delete').forEach(btn => {
            btn.addEventListener('click' ,function(){
                if(confirm('Xóa không ?')){
                    fetch(`${url}/${this.dataset.id}`,{method: 'delete'})
                    .then(() => showbooks());
                }
            })
        });
        document.querySelectorAll('.btn-edit').forEach(btn => {
            btn.addEventListener('click' ,function(){
                window.location.href = `edit.html?id=${this.dataset.id}`
            })
        });
        document.querySelectorAll('.btn-add').forEach(btn => {
            btn.addEventListener('click' ,function(){
                window.location.href = `add.html${this.dataset.id ? '?id=' + this.dataset.id: '' }`
            })
        });
    })
}
showbooks();