const url = 'http://localhost:3000/clothes';
const tbody = document.querySelector('tbody');
function showcolothes() {
    fetch(url)
    .then(res => res.json())
    .then(data => {
        tbody.innerHTML = data.map((clothe,index)=> {
            return `<tr>
                        <th>${index + 1}</th>
                        <th>${clothe.title}</th>
                        <th>${clothe.quantity}</th>
                        <th><img src="${clothe.imageUrl}" alt="Ảnh" width="50px"></th>
                        <th>${clothe.category}</th>
                        <th>
                            <button class="btn  btn-primary btn-edit" data-id="${clothe.id}">Sửa</button>
                            <button class="btn  btn-danger btn-delete" data-id="${clothe.id}">Xóa</button>
                        </th>
                    </tr>`
        }).join('');
        document.querySelectorAll('.btn-delete').forEach(btn => {
            btn.addEventListener('click' ,function() {
                if(confirm('Xóa không ?')){
                    fetch(`${url}/${this.dataset.id}`,{method: 'delete'});
                }
            })
        });
        document.querySelectorAll('.btn-edit').forEach(btn => {
            btn.addEventListener('click' ,function() {
                window.location.href = `edit.html?id=${this.dataset.id}`;
            })
        });
        document.querySelectorAll('.btn-add').forEach(btn => {
            btn.addEventListener('click' ,function() {
                window.location.href = `add.html?id=${this.dataset.id ? '?id=' + this.dataset.id : ''}`;
            })
        });

    })
}
showcolothes();